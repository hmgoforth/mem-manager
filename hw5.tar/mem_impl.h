/* Authors: Ting-Yu (Jacky) Wang, Hunter Goforth
 * Date: 2/15/2016
 * Program: mem_impl.h
 *
 * This header file stores primary struct for the memory
 * management program.
 */
 
#ifndef MEM_IMPL_H
#define MEM_IMPL_H
#include <stdint.h>

// Creating the struct for a memory block of the free list
// Each memory block contains this struct as header
typedef struct block {
    uintptr_t size;  // stores the size of the memory block
    struct free_block *next;  // stores the pointer to the next memory block
} Block;

#endif
