// Authors: Ting-Yu (Jacky) Wang, Hunter Goforth
// Project: Homework 5: Memory Management

#include "mem.h"
#include "mem_impl.h"
#include <inttypes.h>
#include <stdint.h>
#include <stdio.h>

// Returns a pointer to a new block of storage with at least size bytes
// of memory. size must be greater than 0. NULL is returned if size is
// not positive or if getmem cannot satisfy the request.
void* getmem(uintptr_t size) {
    return NULL;
}
