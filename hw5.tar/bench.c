// Authors: Ting-Yu (Jacky) Wang, Hunter Goforth
// Project: Homework 5: Memory Management

/* 
bench allows the user to execute a large number of
calls to the functions getmem and freemem from mem.h
to allocate and free blocks of random sizes and 
in random order. The program allows the following
command-line parameter:

ntrials - total number of getmem plus freemem calls to
randomly perform during the test. Default 10,000

pctget: percent of the total getmem/freemem calls that 
should be getmem. Default 50.

pctlarge: percent of the getmem calls that should request
"large" blocks with a size greater than small_limit. 
Default 10.

small_limit: largest size in bytes of a "small" block. 
Default 200.

large_limit: largest size in bytes of a "large" block. 
Default 20000.

random_seed: initial seed value for the random number generator. 
Default: the system time-of-day clock

*/

#include "mem.h"
#include <stdio.h>
 
int main(int argc, char **argv) {
    return 0;
}

