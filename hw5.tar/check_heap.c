// Authors: Ting-Yu (Jacky) Wang, Hunter Goforth
// Project: Homework 5: Memory Management

#include "mem.h"
#include "mem_impl.h"
#include <stdio.h>

// Checks for problems with the free list data structure and verifies that,
// blocks are ordered with increasing memory addresses,
// block sizes are positive and not smaller than the chosen minimum block size,
// blocks do not overlap and not touching.
// Function returns silently if no errors are detected.
void check_heap() {}

