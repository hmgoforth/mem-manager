// Authors: Ting-Yu (Jacky) Wang, Hunter Goforth
// Project: Homework 5: Memory Management

#include "mem.h"
#include "mem_impl.h"
#include <stdio.h>

// Returns the block of memory at location p. If p is NULL, freemem will
// not take effect. If p has values other than the one returned by getmem
// or if it has previously been released by freemem, then freemem, in this
// case is undefined.
void freemem(void* p) {}
